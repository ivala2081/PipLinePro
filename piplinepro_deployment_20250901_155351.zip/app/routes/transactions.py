"""
Transaction routes blueprint
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, Response
from flask_login import login_required, current_user
from datetime import datetime, date, timedelta, timezone
from sqlalchemy import func, extract, desc, and_, or_
import pandas as pd
from werkzeug.utils import secure_filename
import os
import csv
from io import StringIO
import json
from decimal import Decimal, InvalidOperation
from collections import defaultdict
import logging

from app import db
from app.models.transaction import Transaction
from app.models.user import User
from app.models.config import Option, ExchangeRate
from app.models.financial import PspTrack, DailyBalance
# from app.services.performance_optimized_service import performance_optimized_service
from app.services.decimal_float_fix_service import decimal_float_service
from app.utils.template_helpers import legacy_ultimate_tojson, safe_template_data
from app.services.json_auto_fix_service import json_auto_fix_service
from app.services.datetime_fix_service import datetime_fix_service, fix_template_data_dates
from app.utils.error_handler import handle_errors, handle_api_errors

# Configure logging
logger = logging.getLogger(__name__)

# Create blueprint
transactions_bp = Blueprint('transactions', __name__)

# Define Analytics class outside of route functions to avoid scope issues
class Analytics:
    def __init__(self, total_clients, active_clients, avg_transaction_value, top_client_volume):
        self.total_clients = total_clients
        self.active_clients = active_clients
        self.avg_transaction_value = avg_transaction_value
        self.top_client_volume = top_client_volume

# Define ClientStats class outside of route functions to avoid scope issues
class ClientStats:
    def __init__(self, total_clients, total_volume, avg_transaction, top_client):
        self.total_clients = total_clients
        self.total_volume = total_volume
        self.avg_transaction = avg_transaction
        self.top_client = top_client

# Main transactions route
@transactions_bp.route('/transactions')
@login_required
@handle_errors
def transactions_main():
    """Main transactions page with filtering and pagination"""
    # Get page and filters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 25, type=int)
    
    # Build filters from request parameters
    filters = {
        'date_from': request.args.get('date_from'),
        'date_to': request.args.get('date_to'),
        'client_name': request.args.get('client_name'),
        'psp': request.args.get('psp'),
        'category': request.args.get('category'),
        'currency': request.args.get('currency'),
        'payment_method': request.args.get('payment_method'),
        'company': request.args.get('company')
    }
    
    # Get transactions data with pagination and filters
    query = Transaction.query
    
    # Apply filters
    if filters.get('date_from'):
        query = query.filter(Transaction.date >= filters['date_from'])
    if filters.get('date_to'):
        query = query.filter(Transaction.date <= filters['date_to'])
    if filters.get('client_name'):
        query = query.filter(Transaction.client_name.ilike(f"%{filters['client_name']}%"))
    if filters.get('psp'):
        query = query.filter(Transaction.psp.ilike(f"%{filters['psp']}%"))
    if filters.get('category'):
        query = query.filter(Transaction.category.ilike(f"%{filters['category']}%"))
    if filters.get('currency'):
        query = query.filter(Transaction.currency.ilike(f"%{filters['currency']}%"))
    if filters.get('payment_method'):
        query = query.filter(Transaction.payment_method.ilike(f"%{filters['payment_method']}%"))
    if filters.get('company'):
        query = query.filter(Transaction.company.ilike(f"%{filters['company']}%"))
    
    # Get total count for pagination
    total_count = query.count()
    
    # Apply pagination
    transactions = query.order_by(Transaction.date.desc(), Transaction.created_at.desc()).offset(
        (page - 1) * per_page
    ).limit(per_page).all()
    
    # Calculate pagination info
    total_pages = (total_count + per_page - 1) // per_page
    pagination = {
        'page': page,
        'per_page': per_page,
        'total': total_count,
        'pages': total_pages,
        'has_next': page < total_pages,
        'has_prev': page > 1
    }
    
    # Get distinct values for filters
    psp_options = [r[0] for r in db.session.query(Transaction.psp).distinct().filter(Transaction.psp.isnot(None)).all()]
    category_options = [r[0] for r in db.session.query(Transaction.category).distinct().filter(Transaction.category.isnot(None)).all()]
    currency_options = [r[0] for r in db.session.query(Transaction.currency).distinct().filter(Transaction.currency.isnot(None)).all()]
    payment_method_options = [r[0] for r in db.session.query(Transaction.payment_method).distinct().filter(Transaction.payment_method.isnot(None)).all()]
    
    # Calculate summary statistics
    summary = {
        'total_transactions': total_count,
        'total_amount': sum(t.amount for t in transactions),
        'total_commission': sum(t.commission for t in transactions),
        'total_net': sum(t.net_amount for t in transactions)
    }
    
    return render_template('transactions_content.html',
                         transactions=transactions,
                         pagination=pagination,
                         summary=summary,
                         psp_options=psp_options,
                         category_options=category_options,
                         currency_options=currency_options,
                         payment_method_options=payment_method_options,
                         filters=filters,
                         now=datetime.now())

# Alias routes for compatibility
@transactions_bp.route('/transactions_old')
@login_required
def transactions_alias():
    return redirect(url_for('transactions.clients'))

@transactions_bp.route('/add_transaction')
@login_required
def add_transaction_alias():
    return redirect(url_for('transactions.add'))

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'csv', 'xlsx', 'xls'}

def validate_input(data, field_type='string'):
    """Validate input data"""
    if not data:
        return False, f"{field_type} is required"
    
    if field_type == 'amount':
        try:
            amount = Decimal(str(data))
            if amount <= 0:
                return False, "Amount must be positive"
            return True, amount
        except (InvalidOperation, ValueError):
            return False, "Invalid amount format"
    
    elif field_type == 'date':
        try:
            if isinstance(data, str):
                date_obj = datetime.strptime(data, '%Y-%m-%d').date()
            else:
                date_obj = data
            return True, date_obj
        except ValueError:
            return False, "Invalid date format (YYYY-MM-DD)"
    
    elif field_type == 'decimal':
        try:
            decimal_val = Decimal(str(data))
            return True, decimal_val
        except (InvalidOperation, ValueError):
            return False, "Invalid decimal format"
    
    return True, data

def secure_filename_upload(file):
    """Generate secure filename for upload"""
    filename = secure_filename(file.filename)
    # Add timestamp to prevent conflicts
    name, ext = os.path.splitext(filename)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{name}_{timestamp}{ext}"

def log_audit(action, table_name, record_id, old_values=None, new_values=None):
    """Log audit trail"""
    try:
        from app.models.audit import AuditLog
        audit_log = AuditLog(
            user_id=current_user.id,
            action=action,
            table_name=table_name,
            record_id=record_id,
            old_values=json.dumps(old_values) if old_values else None,
            new_values=json.dumps(new_values) if new_values else None,
            ip_address=request.remote_addr
        )
        db.session.add(audit_log)
        db.session.commit()
    except Exception as e:
        logger.error(f"Failed to log audit: {str(e)}")
        db.session.rollback()

def calculate_commission(amount, psp, category=None):
    """Calculate commission based on PSP and category"""
    try:
        # IMPORTANT: WD (Withdraw) transactions have ZERO commission
        # Company doesn't pay commissions for withdrawals
        if category and category.upper() == 'WD':
            return Decimal('0')
        
        # Get commission rate from PSP options for DEP transactions
        option = Option.query.filter_by(
            field_name='psp',
            value=psp,
            is_active=True
        ).first()
        
        if option and option.commission_rate:
            commission = amount * option.commission_rate
            return commission
        else:
            # Default commission rate of 2.5% for DEP transactions
            return amount * Decimal('0.025')
    except Exception as e:
        logger.error(f"Error calculating commission: {str(e)}")
        return Decimal('0')

def apply_transaction_filters(query):
    """Apply filters to transaction query"""
    # Date range filter
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    if start_date:
        try:
            start_date_obj = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(Transaction.date >= start_date_obj)
        except ValueError:
            pass
    
    if end_date:
        try:
            end_date_obj = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(Transaction.date <= end_date_obj)
        except ValueError:
            pass
    
    # PSP filter
    psp_filter = request.args.get('psp')
    if psp_filter:
        query = query.filter(Transaction.psp == psp_filter)
    
    # Category filter
    category_filter = request.args.get('category')
    if category_filter:
        query = query.filter(Transaction.category == category_filter)
    
    # Currency filter
    currency_filter = request.args.get('currency')
    if currency_filter:
        query = query.filter(Transaction.currency == currency_filter)
    
    # Amount range filter
    min_amount = request.args.get('min_amount')
    max_amount = request.args.get('max_amount')
    
    if min_amount:
        try:
            min_amount_decimal = Decimal(min_amount)
            query = query.filter(Transaction.amount >= min_amount_decimal)
        except (InvalidOperation, ValueError):
            pass
    
    if max_amount:
        try:
            max_amount_decimal = Decimal(max_amount)
            query = query.filter(Transaction.amount <= max_amount_decimal)
        except (InvalidOperation, ValueError):
            pass
    
    return query

@transactions_bp.route('/add', methods=['GET', 'POST'])
@login_required
@handle_errors
def add_transaction():
    """Add new transaction"""
    if request.method == 'POST':
        try:
            # Validate required fields
            client_name = request.form.get('client_name', '').strip()
            if not client_name:
                flash('Client name is required.', 'error')
                return render_template('add_transaction.html')
            
            # Validate amount
            amount_str = request.form.get('amount', '')
            is_valid, amount_result = validate_input(amount_str, 'amount')
            if not is_valid:
                flash(amount_result, 'error')
                return render_template('add_transaction.html')
            amount = amount_result
            
            # Validate date
            date_str = request.form.get('date', '')
            is_valid, date_result = validate_input(date_str, 'date')
            if not is_valid:
                flash(date_result, 'error')
                return render_template('add_transaction.html')
            transaction_date = date_result
            
            # Get other fields
            iban = request.form.get('iban', '').strip()
            payment_method = request.form.get('payment_method', '').strip()
            company_order = request.form.get('company_order', '').strip()
            category = request.form.get('category', '').strip()
            psp = request.form.get('psp', '').strip()
            notes = request.form.get('notes', '').strip()
            currency = request.form.get('currency', 'TL').strip()
            
            # Calculate commission
            commission = calculate_commission(amount, psp, category)
            net_amount = amount - commission
            
            # Create transaction using service (includes automatic PSP sync)
            from app.services.transaction_service import TransactionService
            
            transaction_data = {
                'client_name': client_name,
                'iban': iban,
                'payment_method': payment_method,
                'company_order': company_order,
                'date': transaction_date,
                'category': category,
                'amount': amount,
                'commission': commission,
                'net_amount': net_amount,
                'currency': currency,
                'psp': psp,
                'notes': notes
            }
            
            transaction = TransactionService.create_transaction(transaction_data, current_user.id)
            
            # Log audit
            log_audit('CREATE', 'transaction', transaction.id, None, transaction.to_dict())
            
            flash('Transaction added successfully!', 'success')
            return redirect(url_for('transactions.clients'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error adding transaction: {str(e)}")
            flash('Error adding transaction. Please try again.', 'error')
    
    # Get template variables for dropdowns from Option model
    from app.models.config import Option
    
    # Get options from Option model
    iban_options = Option.query.filter_by(field_name='iban', is_active=True).order_by(Option.value).all()
    ibans = [option.value for option in iban_options]
    
    payment_method_options = Option.query.filter_by(field_name='payment_method', is_active=True).order_by(Option.value).all()
    payment_methods = [option.value for option in payment_method_options]
    
    company_options = Option.query.filter_by(field_name='company_order', is_active=True).order_by(Option.value).all()
    companies = [option.value for option in company_options]
    
    currency_options = Option.query.filter_by(field_name='currency', is_active=True).order_by(Option.value).all()
    currencies = [option.value for option in currency_options]
    
    category_options = Option.query.filter_by(field_name='category', is_active=True).order_by(Option.value).all()
    categories = [option.value for option in category_options]
    
    psp_options = Option.query.filter_by(field_name='psp', is_active=True).order_by(Option.value).all()
    psps = [option.value for option in psp_options]
    
    # Fallback to existing transaction data if no options are configured
    if not ibans:
        ibans = db.session.query(Transaction.iban).distinct().filter(Transaction.iban.isnot(None)).all()
        ibans = [iban[0] for iban in ibans if iban[0]]
    
    if not payment_methods:
        payment_methods = db.session.query(Transaction.payment_method).distinct().filter(Transaction.payment_method.isnot(None)).all()
        payment_methods = [pm[0] for pm in payment_methods if pm[0]]
    
    if not companies:
        companies = db.session.query(Transaction.company_order).distinct().filter(Transaction.company_order.isnot(None)).all()
        companies = [comp[0] for comp in companies if comp[0]]
    
    if not currencies:
        currencies = db.session.query(Transaction.currency).distinct().filter(Transaction.currency.isnot(None)).all()
        currencies = [curr[0] for curr in currencies if curr[0]]
    
    if not categories:
        categories = db.session.query(Transaction.category).distinct().filter(Transaction.category.isnot(None)).all()
        categories = [cat[0] for cat in categories if cat[0]]
    
    if not psps:
        psps = db.session.query(Transaction.psp).distinct().filter(Transaction.psp.isnot(None)).all()
        psps = [psp[0] for psp in psps if psp[0]]
    
    return render_template('add_transaction.html',
                         ibans=ibans,
                         payment_methods=payment_methods,
                         companies=companies,
                         currencies=currencies,
                         categories=categories,
                         psps=psps)

@transactions_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
@handle_errors
def edit_transaction(id):
    """Edit existing transaction"""
    transaction = Transaction.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            # Store old values for audit
            old_values = transaction.to_dict()
            
            # Validate required fields
            client_name = request.form.get('client_name', '').strip()
            if not client_name:
                flash('Client name is required.', 'error')
                return render_template('edit_transaction.html', transaction=transaction)
            
            # Validate amount
            amount_str = request.form.get('amount', '')
            is_valid, amount_result = validate_input(amount_str, 'amount')
            if not is_valid:
                flash(amount_result, 'error')
                return render_template('edit_transaction.html', transaction=transaction)
            amount = amount_result
            
            # Validate date
            date_str = request.form.get('date', '')
            is_valid, date_result = validate_input(date_str, 'date')
            if not is_valid:
                flash(date_result, 'error')
                return render_template('edit_transaction.html', transaction=transaction)
            transaction_date = date_result
            
            # Get other fields
            iban = request.form.get('iban', '').strip()
            payment_method = request.form.get('payment_method', '').strip()
            company_order = request.form.get('company_order', '').strip()
            category = request.form.get('category', '').strip()
            psp = request.form.get('psp', '').strip()
            notes = request.form.get('notes', '').strip()
            currency = request.form.get('currency', 'TL').strip()
            
            # Calculate commission
            commission = calculate_commission(amount, psp, category)
            net_amount = amount - commission
            
            # Update transaction using service (includes automatic PSP sync)
            from app.services.transaction_service import TransactionService
            
            transaction_data = {
                'client_name': client_name,
                'iban': iban,
                'payment_method': payment_method,
                'company_order': company_order,
                'date': transaction_date,
                'category': category,
                'amount': amount,
                'commission': commission,
                'net_amount': net_amount,
                'currency': currency,
                'psp': psp,
                'notes': notes
            }
            
            transaction = TransactionService.update_transaction(transaction.id, transaction_data, current_user.id)
            
            # Log audit
            log_audit('UPDATE', 'transaction', transaction.id, old_values, transaction.to_dict())
            
            flash('Transaction updated successfully!', 'success')
            return redirect(url_for('transactions.clients'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating transaction: {str(e)}")
            flash('Error updating transaction. Please try again.', 'error')
    
    # Get template variables for dropdowns from Option model
    from app.models.config import Option
    
    # Get options from Option model
    iban_options = Option.query.filter_by(field_name='iban', is_active=True).order_by(Option.value).all()
    ibans = [option.value for option in iban_options]
    
    payment_method_options = Option.query.filter_by(field_name='payment_method', is_active=True).order_by(Option.value).all()
    payment_methods = [option.value for option in payment_method_options]
    
    company_options = Option.query.filter_by(field_name='company_order', is_active=True).order_by(Option.value).all()
    companies = [option.value for option in company_options]
    
    currency_options = Option.query.filter_by(field_name='currency', is_active=True).order_by(Option.value).all()
    currencies = [option.value for option in currency_options]
    
    category_options = Option.query.filter_by(field_name='category', is_active=True).order_by(Option.value).all()
    categories = [option.value for option in category_options]
    
    psp_options = Option.query.filter_by(field_name='psp', is_active=True).order_by(Option.value).all()
    psps = [option.value for option in psp_options]
    
    # Fallback to existing transaction data if no options are configured
    if not ibans:
        ibans = db.session.query(Transaction.iban).distinct().filter(Transaction.iban.isnot(None)).all()
        ibans = [iban[0] for iban in ibans if iban[0]]
    
    if not payment_methods:
        payment_methods = db.session.query(Transaction.payment_method).distinct().filter(Transaction.payment_method.isnot(None)).all()
        payment_methods = [pm[0] for pm in payment_methods if pm[0]]
    
    if not companies:
        companies = db.session.query(Transaction.company_order).distinct().filter(Transaction.company_order.isnot(None)).all()
        companies = [comp[0] for comp in companies if comp[0]]
    
    if not currencies:
        currencies = db.session.query(Transaction.currency).distinct().filter(Transaction.currency.isnot(None)).all()
        currencies = [curr[0] for curr in currencies if curr[0]]
    
    if not categories:
        categories = db.session.query(Transaction.category).distinct().filter(Transaction.category.isnot(None)).all()
        categories = [cat[0] for cat in categories if cat[0]]
    
    if not psps:
        psps = db.session.query(Transaction.psp).distinct().filter(Transaction.psp.isnot(None)).all()
        psps = [psp[0] for psp in psps if psp[0]]
    
    return render_template('edit_transaction.html', 
                         transaction=transaction,
                         ibans=ibans,
                         payment_methods=payment_methods,
                         companies=companies,
                         currencies=currencies,
                         categories=categories,
                         psps=psps)

@transactions_bp.route('/delete/<int:id>', methods=['POST'])
@login_required
@handle_errors
def delete_transaction(id):
    """Delete transaction"""
    logger.info(f"DELETE route called for transaction {id}")
    logger.info(f"Request method: {request.method}")
    logger.info(f"Request form data: {request.form}")
    logger.info(f"Request args: {request.args}")
    logger.info(f"Request headers: {dict(request.headers)}")
    
    # Check if this is an AJAX request (which might bypass CSRF)
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    
    transaction = Transaction.query.get_or_404(id)
    
    try:
        # Store old values for audit
        old_values = transaction.to_dict()
        logger.info(f"Transaction found: {old_values}")
        
        # Delete transaction using service (includes automatic PSP sync)
        from app.services.transaction_service import TransactionService
        TransactionService.delete_transaction(transaction.id, current_user.id)
        logger.info(f"Transaction {id} deleted successfully")
        
        # Log audit (temporarily disabled for debugging)
        # try:
        #     log_audit('DELETE', 'transaction', id, old_values, None)
        # except Exception as audit_error:
        #     logger.error(f"Audit logging failed but transaction was deleted: {str(audit_error)}")
        
        if is_ajax:
            return jsonify({
                'success': True,
                'message': 'Transaction deleted successfully!',
                'redirect_url': url_for('transactions.clients')
            })
        else:
            flash('Transaction deleted successfully!', 'success')
            return redirect(url_for('transactions.clients'))
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting transaction {id}: {str(e)}")
        
        if is_ajax:
            return jsonify({
                'success': False,
                'message': 'Error deleting transaction. Please try again.'
            }), 500
        else:
            flash('Error deleting transaction. Please try again.', 'error')
            return redirect(url_for('transactions.clients'))



@transactions_bp.route('/api/delete/<int:id>', methods=['POST'])
@login_required
@handle_api_errors
def api_delete_transaction(id):
    """API delete transaction - bypasses CSRF for AJAX calls"""
    logger.info(f"API DELETE route called for transaction {id}")
    logger.info(f"Request method: {request.method}")
    logger.info(f"Request form data: {request.form}")
    logger.info(f"Request args: {request.args}")
    logger.info(f"Request headers: {dict(request.headers)}")
    
    transaction = Transaction.query.get_or_404(id)
    
    try:
        # Store old values for audit
        old_values = transaction.to_dict()
        logger.info(f"Transaction found: {old_values}")
        
        # Delete transaction using service (includes automatic PSP sync)
        from app.services.transaction_service import TransactionService
        TransactionService.delete_transaction(transaction.id, current_user.id)
        logger.info(f"Transaction {id} deleted successfully via API")
        
        return jsonify({
            'success': True,
            'message': 'Transaction deleted successfully!',
            'redirect_url': url_for('transactions.clients')
        })
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting transaction {id} via API: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Error deleting transaction. Please try again.'
        }), 500

@transactions_bp.route('/api/sync-psp-track', methods=['POST'])
@login_required
def api_sync_psp_track():
    """Manual API endpoint to sync PSP Track data"""
    try:
        from app.services.data_sync_service import DataSyncService
        
        # Get current transaction count
        transaction_count = Transaction.query.count()
        
        # Sync PSP Track data
        DataSyncService.sync_psp_track_from_transactions()
        
        # Get new PSP Track count
        from app.models.financial import PspTrack
        psp_track_count = PspTrack.query.count()
        
        logger.info(f"Manual PSP Track sync completed. Transactions: {transaction_count}, PSP Tracks: {psp_track_count}")
        
        return jsonify({
            'success': True,
            'message': f'PSP Track synced successfully! Transactions: {transaction_count}, PSP Tracks: {psp_track_count}',
            'transaction_count': transaction_count,
            'psp_track_count': psp_track_count
        })
    except Exception as e:
        logger.error(f"Error in manual PSP Track sync: {str(e)}")
        return jsonify({
            'success': False,
            'message': f'Error syncing PSP Track: {str(e)}'
        }), 500

@transactions_bp.route('/clients')
@login_required
@handle_errors
def clients():
    """Clients management page with tabs - PERFORMANCE OPTIMIZED"""
    # Get active tab
    active_tab = request.args.get('tab', 'overview')
    
    # Get page and filters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 25, type=int)
    
    # Build filters from request parameters
    filters = {
        'date_from': request.args.get('date_from'),
        'date_to': request.args.get('date_to'),
        'amount_min': request.args.get('amount_min') if request.args.get('amount_min') else None,
        'client': request.args.get('client'),
        'psp': request.args.get('psp'),
        'category': request.args.get('category'),
        'currency': request.args.get('currency'),
        'payment_method': request.args.get('payment_method'),
        'company_order': request.args.get('company')
    }
    
    # Fix filters using automation service to prevent type mismatches
    from app.services.decimal_float_automation_service import decimal_float_automation_service
    filters = decimal_float_automation_service.fix_database_filters(filters)
    
    # Use optimized service to get all data
    try:
        # page_data = performance_optimized_service.get_clients_page_data(page, per_page, filters)
        
        # Extract data from optimized service - temporarily disabled
        # transactions = page_data['transactions']
        # distinct_values = page_data['distinct_values']
        # pagination = page_data['pagination']
        # summary = page_data['summary']
        
        # Get transactions data with pagination and filters
        query = Transaction.query
        
        # Apply filters
        if filters.get('date_from'):
            query = query.filter(Transaction.date >= filters['date_from'])
        if filters.get('date_to'):
            query = query.filter(Transaction.date <= filters['date_to'])
        if filters.get('client'):
            query = query.filter(Transaction.client_name.ilike(f"%{filters['client']}%"))
        if filters.get('psp'):
            query = query.filter(Transaction.psp.ilike(f"%{filters['psp']}%"))
        if filters.get('category'):
            query = query.filter(Transaction.category.ilike(f"%{filters['category']}%"))
        if filters.get('currency'):
            query = query.filter(Transaction.currency.ilike(f"%{filters['currency']}%"))
        if filters.get('payment_method'):
            query = query.filter(Transaction.payment_method.ilike(f"%{filters['payment_method']}%"))
        if filters.get('company_order'):
            query = query.filter(Transaction.company.ilike(f"%{filters['company_order']}%"))
        
        # Get total count for pagination
        total_count = query.count()
        
        # Apply pagination
        transactions = query.order_by(Transaction.date.desc(), Transaction.created_at.desc()).offset(
            (page - 1) * per_page
        ).limit(per_page).all()
        
        # Calculate pagination info
        total_pages = (total_count + per_page - 1) // per_page
        pagination = {
            'page': page,
            'per_page': per_page,
            'total': total_count,
            'pages': total_pages,
            'has_next': page < total_pages,
            'has_prev': page > 1
        }
        
        # Get distinct values for filters
        distinct_values = {
            'payment_method': [r[0] for r in db.session.query(Transaction.payment_method).distinct().filter(Transaction.payment_method.isnot(None)).all()],
            'category': [r[0] for r in db.session.query(Transaction.category).distinct().filter(Transaction.category.isnot(None)).all()],
            'psp': [r[0] for r in db.session.query(Transaction.psp).distinct().filter(Transaction.psp.isnot(None)).all()],
            'company_order': [r[0] for r in db.session.query(Transaction.company).distinct().filter(Transaction.company.isnot(None)).all()],
            'currency': [r[0] for r in db.session.query(Transaction.currency).distinct().filter(Transaction.currency.isnot(None)).all()]
        }
        
        # Calculate summary statistics
        summary = {
            'total_transactions': total_count,
            'total_amount': sum(t.amount for t in transactions),
            'total_commission': sum(t.commission for t in transactions),
            'total_net': sum(t.net_amount for t in transactions)
        }
        
        # Get all unique clients (for overview tab) - OPTIMIZED QUERY
        clients_data = db.session.query(
            Transaction.client_name,
            func.count(Transaction.id).label('transaction_count'),
            func.sum(Transaction.amount).label('total_amount'),
            func.sum(Transaction.commission).label('commission'),
            func.sum(Transaction.net_amount).label('net_amount'),
            func.max(Transaction.date).label('last_transaction_date')
        ).filter(
            Transaction.client_name.isnot(None),
            Transaction.client_name != ''
        ).group_by(Transaction.client_name).all()
        
        # Format client data
        clients = []
        for client in clients_data:
            clients.append({
                'name': client.client_name,
                'transaction_count': client.transaction_count,
                'total_amount': float(client.total_amount or 0),
                'volume': float(client.total_amount or 0),  # Add volume property for template compatibility
                'commission': float(client.commission or 0),
                'net_amount': float(client.net_amount or 0),
                'last_transaction_date': client.last_transaction_date,
                'is_active': client.last_transaction_date and (datetime.now().date() - client.last_transaction_date).days < 30 if client.last_transaction_date else False
            })
        
        # Calculate client statistics
        total_clients = len(clients)
        total_volume = sum(c['total_amount'] for c in clients)
        avg_transaction = total_volume / sum(c['transaction_count'] for c in clients) if sum(c['transaction_count'] for c in clients) > 0 else 0
        top_client = max(clients, key=lambda x: x['total_amount'])['name'] if clients else 'N/A'
        
        # Create client_stats as an object for template access
        client_stats = ClientStats(total_clients, total_volume, avg_transaction, top_client)
        
        # Get chart data for overview
        client_chart_data = None
        if clients:
            top_10_clients = sorted(clients, key=lambda x: x['total_amount'], reverse=True)[:10]
            client_chart_data = {
                'labels': [c['name'] for c in top_10_clients],
                'volumes': [c['total_amount'] for c in top_10_clients],
                'net_amounts': [c['net_amount'] for c in top_10_clients]
            }
        
        # Get filter values for transactions tab
        filter_client = request.args.get('client', '')
        filter_payment = request.args.get('payment_method', '')
        filter_category = request.args.get('category', '')
        filter_psp = request.args.get('psp', '')
        filter_company = request.args.get('company', '')
        filter_currency = request.args.get('currency', '')
        
        # Get analytics data
        analytics = {
            'total_clients': total_clients,
            'active_clients': len([c for c in clients if c['is_active']]),
            'avg_transaction_value': avg_transaction,
        }
        
        # Calculate top client volume
        top_client_volume = max(c['total_amount'] for c in clients) if clients else 0
        
        analytics = Analytics(
            total_clients=analytics['total_clients'],
            active_clients=analytics['active_clients'],
            avg_transaction_value=analytics['avg_transaction_value'],
            top_client_volume=top_client_volume
        )
        
        # Get filter options from distinct values
        payment_methods = distinct_values.get('payment_method', [])
        categories = distinct_values.get('category', [])
        psps = distinct_values.get('psp', [])
        companies = distinct_values.get('company_order', [])
        currencies = distinct_values.get('currency', [])
        
        # Get available clients for filter
        available_clients = [c['name'] for c in clients]
        
        # Prepare chart data
        top_clients = sorted(clients, key=lambda x: x['total_amount'], reverse=True)[:5]
        recent_activity = transactions[:5] if transactions else []
        
        # Volume chart data
        volume_chart_data = {
            'labels': [c['name'] for c in top_clients],
            'volumes': [c['total_amount'] for c in top_clients]
        }
        
        # Distribution chart data (top 5 clients + others)
        if len(clients) > 5:
            top_5 = clients[:5]
            others_total = sum(c['total_amount'] for c in clients[5:])
            distribution_chart_data = {
                'labels': [c['name'] for c in top_5] + ['Others'],
                'values': [c['total_amount'] for c in top_5] + [others_total]
            }
        else:
            distribution_chart_data = {
                'labels': [c['name'] for c in clients],
                'values': [c['total_amount'] for c in clients]
            }
            
        # Chart data will be serialized by the template filters
        
        # Identify risk clients (inactive for more than 30 days)
        risk_clients = [c for c in clients if not c['is_active']]
        
        # Create opportunity clients (clients with high potential for growth)
        opportunity_clients = []
        for client in clients:
            if client['is_active'] and client['total_amount'] > 0:
                # Calculate potential based on transaction history
                avg_transaction = client['total_amount'] / client['transaction_count'] if client['transaction_count'] > 0 else 0
                potential_value = avg_transaction * 2  # Assume 2x potential
                
                opportunity_clients.append({
                    'client_name': client['name'],
                    'opportunity_description': f"High-value client with {client['transaction_count']} transactions",
                    'potential_value': potential_value
                })
        
        # Limit to top 3 opportunities
        opportunity_clients = sorted(opportunity_clients, key=lambda x: x['potential_value'], reverse=True)[:3]
            
    except Exception as e:
        logger.error(f"Error in clients page: {str(e)}")
        flash('Error loading clients data', 'error')
        
        # Return safe default values
        return render_template('clients.html',
                             active_tab=active_tab,
                             clients=[],
                             client_stats={'total_clients': 0, 'total_volume': 0, 'avg_transaction': 0, 'top_client': 'N/A'},
                             client_chart_data=None,
                             transactions=[],
                             pagination={'page': 1, 'per_page': 25, 'total_count': 0, 'total_pages': 0, 'has_next': False, 'has_prev': False},
                             available_clients=[],
                             selected_client='',
                             filters={},
                             analytics=Analytics(0, 0, 0, 0),
                             top_clients=[],
                             recent_activity=[],
                             volume_chart_data={'labels': [], 'volumes': []},
                             distribution_chart_data={'labels': [], 'values': []},
                             filter_client='',
                             filter_payment='',
                             filter_category='',
                             filter_psp='',
                             filter_company='',
                             filter_currency='',
                             payment_methods=[],
                             categories=[],
                             psps=[],
                             companies=[],
                             currencies=[],
                             risk_clients=[],
                             opportunity_clients=[],
                             now=datetime.now())
    
    # Auto-fix all template data for JSON compatibility
    template_data = {
        'active_tab': active_tab,
        'clients': clients,
        'client_stats': client_stats,
        'client_chart_data': client_chart_data,
        'transactions': transactions,
        'pagination': pagination,
        'available_clients': available_clients,
        'selected_client': filters.get('client'),
        'filters': filters,
        'analytics': analytics,
        'top_clients': top_clients,
        'recent_activity': recent_activity,
        'volume_chart_data': volume_chart_data,
        'distribution_chart_data': distribution_chart_data,
        'filter_client': filter_client,
        'filter_payment': filter_payment,
        'filter_category': filter_category,
        'filter_psp': filter_psp,
        'filter_company': filter_company,
        'filter_currency': filter_currency,
        'payment_methods': payment_methods,
        'categories': categories,
        'psps': psps,
        'companies': companies,
        'currencies': currencies,
        'risk_clients': risk_clients,
        'opportunity_clients': opportunity_clients,
        'now': datetime.now()
    }
    
    # Apply automated JSON fixing to all template data
    safe_data = json_auto_fix_service.auto_fix_template_data(template_data)
    
    # Apply datetime fixing to all template data
    safe_data = fix_template_data_dates(safe_data)
    
    return render_template('clients.html', **safe_data)



@transactions_bp.route('/import', methods=['GET', 'POST'])
@login_required
@handle_errors
def import_transactions():
    """Import transactions from CSV/Excel file"""
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file selected.', 'error')
            return render_template('import_transactions.html')
        
        file = request.files['file']
        if file.filename == '':
            flash('No file selected.', 'error')
            return render_template('import_transactions.html')
        
        if not allowed_file(file.filename):
            flash('Invalid file type. Please upload CSV or Excel file.', 'error')
            return render_template('import_transactions.html')
        
        try:
            # Read file
            if file.filename.endswith('.csv'):
                df = pd.read_csv(file)
            else:
                df = pd.read_excel(file)
            
            # Validate required columns
            required_columns = ['client_name', 'amount', 'date']
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                flash(f'Missing required columns: {", ".join(missing_columns)}', 'error')
                return render_template('import_transactions.html')
            
            # Process transactions
            success_count = 0
            error_count = 0
            
            for index, row in df.iterrows():
                try:
                    # Validate data
                    client_name = str(row['client_name']).strip()
                    if not client_name:
                        continue
                    
                    # Validate amount
                    amount_str = str(row['amount'])
                    is_valid, amount_result = validate_input(amount_str, 'amount')
                    if not is_valid:
                        error_count += 1
                        continue
                    amount = amount_result
                    
                    # Validate date
                    date_str = str(row['date'])
                    is_valid, date_result = validate_input(date_str, 'date')
                    if not is_valid:
                        error_count += 1
                        continue
                    transaction_date = date_result
                    
                    # Get other fields
                    iban = str(row.get('iban', '')).strip()
                    payment_method = str(row.get('payment_method', '')).strip()
                    company_order = str(row.get('company_order', '')).strip()
                    category = str(row.get('category', '')).strip()
                    psp = str(row.get('psp', '')).strip()
                    notes = str(row.get('notes', '')).strip()
                    currency = str(row.get('currency', 'TL')).strip()
                    
                    # Calculate commission
                    commission = calculate_commission(amount, psp, category)
                    net_amount = amount - commission
                    
                    # Create transaction using service (includes automatic PSP sync)
                    from app.services.transaction_service import TransactionService
                    
                    transaction_data = {
                        'client_name': client_name,
                        'iban': iban,
                        'payment_method': payment_method,
                        'company_order': company_order,
                        'date': transaction_date,
                        'category': category,
                        'amount': amount,
                        'commission': commission,
                        'net_amount': net_amount,
                        'currency': currency,
                        'psp': psp,
                        'notes': notes
                    }
                    
                    TransactionService.create_transaction(transaction_data, current_user.id)
                    success_count += 1
                    
                except Exception as e:
                    error_count += 1
                    logger.error(f"Error processing row {index}: {str(e)}")
                    continue
            
            db.session.commit()
            
            flash(f'Import completed! {success_count} transactions imported, {error_count} errors.', 'success')
            return redirect(url_for('transactions.clients'))
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error importing transactions: {str(e)}")
            flash('Error importing transactions. Please check file format.', 'error')
    
    return render_template('import_transactions.html')

@transactions_bp.route('/export')
@login_required
@handle_errors
def export_transactions():
    """Export transactions to CSV"""
    try:
        # Build query
        query = Transaction.query
        
        # Apply filters
        query = apply_transaction_filters(query)
        
        # Order by date (newest first)
        query = query.order_by(desc(Transaction.date))
        
        transactions = query.all()
        
        # Create CSV
        output = StringIO()
        writer = csv.writer(output)
        
        # Write header
        writer.writerow([
            'ID', 'Client Name', 'IBAN', 'Payment Method', 'Company Order',
            'Date', 'Category', 'Amount', 'Commission', 'Net Amount',
            'Currency', 'PSP', 'Notes', 'Created At'
        ])
        
        # Write data
        for transaction in transactions:
            writer.writerow([
                transaction.id,
                transaction.client_name,
                transaction.iban or '',
                transaction.payment_method or '',
                transaction.company_order or '',
                transaction.date.strftime('%Y-%m-%d'),
                transaction.category or '',
                float(transaction.amount),
                float(transaction.commission),
                float(transaction.net_amount),
                transaction.currency,
                transaction.psp or '',
                transaction.notes or '',
                transaction.created_at.strftime('%Y-%m-%d %H:%M:%S') if transaction.created_at else ''
            ])
        
        # Create response
        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype='text/csv',
            headers={'Content-Disposition': 'attachment; filename=transactions.csv'}
        )
        
    except Exception as e:
        logger.error(f"Error exporting transactions: {str(e)}")
        flash('Error exporting transactions.', 'error')
        return redirect(url_for('transactions.clients'))

@transactions_bp.route('/view/<int:transaction_id>')
@login_required
def view_transaction(transaction_id):
    """View transaction details page"""
    transaction = Transaction.query.get_or_404(transaction_id)
    
    # Get related transactions for this client
    related_transactions = Transaction.query.filter_by(
        client_name=transaction.client_name
    ).filter(
        Transaction.id != transaction_id
    ).order_by(desc(Transaction.date)).limit(5).all()
    
    return render_template('view_transaction.html', 
                         transaction=transaction,
                         related_transactions=related_transactions)

@transactions_bp.route('/daily_summary/<date>', methods=['GET', 'POST'])
@login_required
def daily_summary(date):
    """Show daily summary for a specific date"""
    try:
        # Parse date
        try:
            date_obj = datetime.strptime(date, '%Y-%m-%d').date()
        except ValueError:
            flash('Invalid date format. Please use YYYY-MM-DD format.', 'error')
            return redirect(url_for('transactions.clients'))
        
        # Handle USD rate update
        if request.method == 'POST':
            usd_rate = request.form.get('usd_rate')
            if usd_rate:
                try:
                    usd_rate = Decimal(str(usd_rate))
                    if usd_rate <= 0:
                        flash('USD rate must be positive.', 'error')
                    else:
                        # Update or create exchange rate for this date
                        from app.models.config import ExchangeRate
                        exchange_rate = ExchangeRate.query.filter_by(date=date_obj).first()
                        if exchange_rate:
                            exchange_rate.usd_to_tl = usd_rate
                        else:
                            exchange_rate = ExchangeRate(
                                date=date_obj,
                                usd_to_tl=usd_rate
                            )
                            db.session.add(exchange_rate)
                        
                        db.session.commit()
                        flash('USD rate updated successfully!', 'success')
                        
                        # Redirect back to the same daily summary page to show updated data
                        return redirect(url_for('transactions.daily_summary', date=date))
                        
                except (ValueError, InvalidOperation):
                    flash('Invalid USD rate format.', 'error')
        
        # Get all transactions for the date
        transactions = Transaction.query.filter_by(date=date_obj).order_by(Transaction.created_at.desc()).all()
        
        # Allow viewing daily summary even without transactions (for setting USD rate)
        if not transactions:
            # Get exchange rate for this date
            from app.models.config import ExchangeRate
            exchange_rate = ExchangeRate.query.filter_by(date=date_obj).first()
            usd_rate = decimal_float_service.safe_decimal(exchange_rate.usd_to_tl) if exchange_rate and exchange_rate.usd_to_tl else None
            
            # Show empty summary with USD rate form
            summary_data = {
                'date': date_obj,
                'date_str': date_obj.strftime('%A, %B %d, %Y'),
                'usd_rate': float(usd_rate) if usd_rate else None,
                'total_amount_tl': 0.0,
                'total_amount_usd': 0.0,
                'total_commission_tl': 0.0,
                'total_commission_usd': 0.0,
                'total_net_tl': 0.0,
                'total_net_usd': 0.0,
                'transaction_count': 0,
                'unique_clients': 0,
                'psp_summary': [],
                'category_summary': [],
                'payment_method_summary': [],
                'transactions': []
            }
            
            return render_template('daily_summary.html', **summary_data)
        
        # Get exchange rate for this date
        from app.models.config import ExchangeRate
        exchange_rate = ExchangeRate.query.filter_by(date=date_obj).first()
        usd_rate = decimal_float_service.safe_decimal(exchange_rate.usd_to_tl) if exchange_rate and exchange_rate.usd_to_tl else None
        
        # Calculate summary statistics with USD conversion
        total_amount_tl = Decimal('0')
        total_amount_usd = Decimal('0')
        total_commission_tl = Decimal('0')
        total_commission_usd = Decimal('0')
        total_net_tl = Decimal('0')
        total_net_usd = Decimal('0')
        
        for transaction in transactions:
            if transaction.currency and transaction.currency.upper() == 'USD':
                total_amount_usd += decimal_float_service.safe_decimal(transaction.amount)
                total_commission_usd += decimal_float_service.safe_decimal(transaction.commission)
                total_net_usd += decimal_float_service.safe_decimal(transaction.net_amount)
                # Convert USD to TL for total calculations
                if usd_rate and usd_rate != Decimal('0'):
                    total_amount_tl += decimal_float_service.safe_multiply(transaction.amount, usd_rate, 'decimal')
                    total_commission_tl += decimal_float_service.safe_multiply(transaction.commission, usd_rate, 'decimal')
                    total_net_tl += decimal_float_service.safe_multiply(transaction.net_amount, usd_rate, 'decimal')
                else:
                    total_amount_tl += decimal_float_service.safe_decimal(transaction.amount)  # Fallback to USD amount
                    total_commission_tl += decimal_float_service.safe_decimal(transaction.commission)
                    total_net_tl += decimal_float_service.safe_decimal(transaction.net_amount)
            else:
                # TL transactions
                total_amount_tl += decimal_float_service.safe_decimal(transaction.amount)
                total_commission_tl += decimal_float_service.safe_decimal(transaction.commission)
                total_net_tl += decimal_float_service.safe_decimal(transaction.net_amount)
        
        transaction_count = len(transactions)
        
        # Group by PSP
        psp_data = defaultdict(lambda: {
            'amount_tl': Decimal('0'),
            'amount_usd': Decimal('0'),
            'commission_tl': Decimal('0'),
            'commission_usd': Decimal('0'),
            'net_tl': Decimal('0'),
            'net_usd': Decimal('0'),
            'count': 0,
            'transactions': []
        })
        
        for transaction in transactions:
            psp = transaction.psp or 'Unknown'
            if transaction.currency and transaction.currency.upper() == 'USD':
                psp_data[psp]['amount_usd'] += decimal_float_service.safe_decimal(transaction.amount)
                psp_data[psp]['commission_usd'] += decimal_float_service.safe_decimal(transaction.commission)
                psp_data[psp]['net_usd'] += decimal_float_service.safe_decimal(transaction.net_amount)
                # Convert to TL for total calculations
                if usd_rate and usd_rate != Decimal('0'):
                    psp_data[psp]['amount_tl'] += decimal_float_service.safe_multiply(transaction.amount, usd_rate, 'decimal')
                    psp_data[psp]['commission_tl'] += decimal_float_service.safe_multiply(transaction.commission, usd_rate, 'decimal')
                    psp_data[psp]['net_tl'] += decimal_float_service.safe_multiply(transaction.net_amount, usd_rate, 'decimal')
                else:
                    psp_data[psp]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                    psp_data[psp]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                    psp_data[psp]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
            else:
                psp_data[psp]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                psp_data[psp]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                psp_data[psp]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
            psp_data[psp]['count'] += 1
            psp_data[psp]['transactions'].append(transaction)
        
        # Group by category
        category_data = defaultdict(lambda: {
            'amount_tl': Decimal('0'),
            'amount_usd': Decimal('0'),
            'commission_tl': Decimal('0'),
            'commission_usd': Decimal('0'),
            'net_tl': Decimal('0'),
            'net_usd': Decimal('0'),
            'count': 0
        })
        
        for transaction in transactions:
            category = transaction.category or 'Unknown'
            if transaction.currency and transaction.currency.upper() == 'USD':
                category_data[category]['amount_usd'] += decimal_float_service.safe_decimal(transaction.amount)
                category_data[category]['commission_usd'] += decimal_float_service.safe_decimal(transaction.commission)
                category_data[category]['net_usd'] += decimal_float_service.safe_decimal(transaction.net_amount)
                # Convert to TL for total calculations
                if usd_rate and usd_rate != Decimal('0'):
                    category_data[category]['amount_tl'] += decimal_float_service.safe_multiply(transaction.amount, usd_rate, 'decimal')
                    category_data[category]['commission_tl'] += decimal_float_service.safe_multiply(transaction.commission, usd_rate, 'decimal')
                    category_data[category]['net_tl'] += decimal_float_service.safe_multiply(transaction.net_amount, usd_rate, 'decimal')
                else:
                    category_data[category]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                    category_data[category]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                    category_data[category]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
            else:
                category_data[category]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                category_data[category]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                category_data[category]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
            category_data[category]['count'] += 1
        
        # Group by payment method
        payment_method_data = defaultdict(lambda: {
            'amount_tl': Decimal('0'),
            'amount_usd': Decimal('0'),
            'commission_tl': Decimal('0'),
            'commission_usd': Decimal('0'),
            'net_tl': Decimal('0'),
            'net_usd': Decimal('0'),
            'count': 0
        })
        
        for transaction in transactions:
            payment_method = transaction.payment_method or 'Unknown'
            if transaction.currency and transaction.currency.upper() == 'USD':
                payment_method_data[payment_method]['amount_usd'] += decimal_float_service.safe_decimal(transaction.amount)
                payment_method_data[payment_method]['commission_usd'] += decimal_float_service.safe_decimal(transaction.commission)
                payment_method_data[payment_method]['net_usd'] += decimal_float_service.safe_decimal(transaction.net_amount)
                # Convert to TL for total calculations
                if usd_rate and usd_rate != Decimal('0'):
                    payment_method_data[payment_method]['amount_tl'] += decimal_float_service.safe_multiply(transaction.amount, usd_rate, 'decimal')
                    payment_method_data[payment_method]['commission_tl'] += decimal_float_service.safe_multiply(transaction.commission, usd_rate, 'decimal')
                    payment_method_data[payment_method]['net_tl'] += decimal_float_service.safe_multiply(transaction.net_amount, usd_rate, 'decimal')
                else:
                    payment_method_data[payment_method]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                    payment_method_data[payment_method]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                    payment_method_data[payment_method]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
            else:
                payment_method_data[payment_method]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                payment_method_data[payment_method]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                payment_method_data[payment_method]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
            payment_method_data[payment_method]['count'] += 1
        
        # Get unique clients
        unique_clients = len(set(t.client_name for t in transactions if t.client_name))
        
        # Format PSP data for template
        psp_summary = []
        for psp, data in psp_data.items():
            psp_summary.append({
                'name': psp,
                'amount_tl': float(data['amount_tl']),
                'amount_usd': float(data['amount_usd']),
                'commission_tl': float(data['commission_tl']),
                'commission_usd': float(data['commission_usd']),
                'net_tl': float(data['net_tl']),
                'net_usd': float(data['net_usd']),
                'count': data['count']
            })
        
        # Format category data for template
        category_summary = []
        for category, data in category_data.items():
            category_summary.append({
                'name': category,
                'amount_tl': float(data['amount_tl']),
                'amount_usd': float(data['amount_usd']),
                'commission_tl': float(data['commission_tl']),
                'commission_usd': float(data['commission_usd']),
                'net_tl': float(data['net_tl']),
                'net_usd': float(data['net_usd']),
                'count': data['count']
            })
        
        # Format payment method data for template
        payment_method_summary = []
        for payment_method, data in payment_method_data.items():
            payment_method_summary.append({
                'name': payment_method,
                'amount_tl': float(data['amount_tl']),
                'amount_usd': float(data['amount_usd']),
                'commission_tl': float(data['commission_tl']),
                'commission_usd': float(data['commission_usd']),
                'net_tl': float(data['net_tl']),
                'net_usd': float(data['net_usd']),
                'count': data['count']
            })
        
        # Sort by TL amount (descending)
        psp_summary.sort(key=lambda x: x['amount_tl'], reverse=True)
        category_summary.sort(key=lambda x: x['amount_tl'], reverse=True)
        payment_method_summary.sort(key=lambda x: x['amount_tl'], reverse=True)
        
        summary_data = {
            'date': date_obj,
            'date_str': date_obj.strftime('%A, %B %d, %Y'),
            'usd_rate': float(usd_rate) if usd_rate else None,
            'total_amount_tl': float(total_amount_tl),
            'total_amount_usd': float(total_amount_usd),
            'total_commission_tl': float(total_commission_tl),
            'total_commission_usd': float(total_commission_usd),
            'total_net_tl': float(total_net_tl),
            'total_net_usd': float(total_net_usd),
            'transaction_count': transaction_count,
            'unique_clients': unique_clients,
            'psp_summary': psp_summary,
            'category_summary': category_summary,
            'payment_method_summary': payment_method_summary,
            'transactions': transactions
        }
        
        return render_template('daily_summary.html', **summary_data)
        
    except Exception as e:
        logger.error(f"Error in daily summary: {str(e)}")
        flash(f'Error loading daily summary for {date}: {str(e)}', 'error')
        # Instead of redirecting to clients, show an error page
        return render_template('daily_summary.html', 
                             date=datetime.strptime(date, '%Y-%m-%d').date() if date else None,
                             date_str=date,
                             error_message=str(e),
                             transactions=[],
                             total_amount_tl=0.0,
                             total_amount_usd=0.0,
                             total_commission_tl=0.0,
                             total_commission_usd=0.0,
                             total_net_tl=0.0,
                             total_net_usd=0.0,
                             transaction_count=0,
                             unique_clients=0,
                             psp_summary=[],
                             category_summary=[],
                             payment_method_summary=[])

@transactions_bp.route('/api/<int:transaction_id>')
@login_required
def get_transaction_details(transaction_id):
    """Get transaction details via API"""
    transaction = Transaction.query.get_or_404(transaction_id)
    
    return jsonify({
        'id': transaction.id,
        'client_name': transaction.client_name,
        'iban': transaction.iban,
        'payment_method': transaction.payment_method,
        'company_order': transaction.company_order,
        'date': transaction.date.strftime('%Y-%m-%d'),
        'category': transaction.category,
        'amount': float(transaction.amount),
        'commission': float(transaction.commission),
        'net_amount': float(transaction.net_amount),
        'currency': transaction.currency,
        'psp': transaction.psp,
        'notes': transaction.notes,
        'created_at': transaction.created_at.strftime('%Y-%m-%d %H:%M:%S') if transaction.created_at else None
    })

@transactions_bp.route('/summary/<date>', methods=['GET', 'POST'])
@login_required
def summary_view(date):
    """Alternative summary route - DEFINITE SOLUTION"""
    try:
        return daily_summary(date)
    except Exception as e:
        logger.error(f"Error in summary_view for date {date}: {str(e)}")
        flash(f'Error loading summary for {date}: {str(e)}', 'error')
        # Instead of redirecting to clients, show an error page
        return render_template('daily_summary.html', 
                             date=datetime.strptime(date, '%Y-%m-%d').date() if date else None,
                             date_str=date,
                             error_message=str(e),
                             transactions=[],
                             total_amount_tl=0.0,
                             total_amount_usd=0.0,
                             total_commission_tl=0.0,
                             total_commission_usd=0.0,
                             total_net_tl=0.0,
                             total_net_usd=0.0,
                             transaction_count=0,
                             unique_clients=0,
                             psp_summary=[],
                             category_summary=[],
                             payment_method_summary=[])

@transactions_bp.route('/api/summary/<date>')
@login_required
def api_summary(date):
    """API endpoint for summary data - MODAL SOLUTION"""
    try:
        # Parse date
        try:
            date_obj = datetime.strptime(date, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date format'}), 400
        
        # Get all transactions for the date
        transactions = Transaction.query.filter_by(date=date_obj).order_by(Transaction.created_at.desc()).all()
        
        # Get exchange rate for this date
        from app.models.config import ExchangeRate
        exchange_rate = ExchangeRate.query.filter_by(date=date_obj).first()
        usd_rate = decimal_float_service.safe_decimal(exchange_rate.usd_to_tl) if exchange_rate and exchange_rate.usd_to_tl else None
        
        # Calculate summary statistics
        total_amount_tl = Decimal('0')
        total_amount_usd = Decimal('0')
        total_commission_tl = Decimal('0')
        total_commission_usd = Decimal('0')
        total_net_tl = Decimal('0')
        total_net_usd = Decimal('0')
        
        for transaction in transactions:
            if transaction.currency and transaction.currency.upper() == 'USD':
                total_amount_usd += decimal_float_service.safe_decimal(transaction.amount)
                total_commission_usd += decimal_float_service.safe_decimal(transaction.commission)
                total_net_usd += decimal_float_service.safe_decimal(transaction.net_amount)
                if usd_rate:
                    total_amount_tl += decimal_float_service.safe_multiply(transaction.amount, usd_rate, 'decimal')
                    total_commission_tl += decimal_float_service.safe_multiply(transaction.commission, usd_rate, 'decimal')
                    total_net_tl += decimal_float_service.safe_multiply(transaction.net_amount, usd_rate, 'decimal')
                else:
                    total_amount_tl += decimal_float_service.safe_decimal(transaction.amount)
                    total_commission_tl += decimal_float_service.safe_decimal(transaction.commission)
                    total_net_tl += decimal_float_service.safe_decimal(transaction.net_amount)
            else:
                total_amount_tl += decimal_float_service.safe_decimal(transaction.amount)
                total_commission_tl += decimal_float_service.safe_decimal(transaction.commission)
                total_net_tl += decimal_float_service.safe_decimal(transaction.net_amount)
        
        # Group by PSP
        psp_data = defaultdict(lambda: {
            'amount_tl': Decimal('0'),
            'amount_usd': Decimal('0'),
            'commission_tl': Decimal('0'),
            'commission_usd': Decimal('0'),
            'net_tl': Decimal('0'),
            'net_usd': Decimal('0'),
            'count': 0
        })
        
        # Group by Category
        category_data = defaultdict(lambda: {
            'amount_tl': Decimal('0'),
            'amount_usd': Decimal('0'),
            'commission_tl': Decimal('0'),
            'commission_usd': Decimal('0'),
            'net_tl': Decimal('0'),
            'net_usd': Decimal('0'),
            'count': 0
        })
        
        # Group by Payment Method
        payment_method_data = defaultdict(lambda: {
            'amount_tl': Decimal('0'),
            'amount_usd': Decimal('0'),
            'commission_tl': Decimal('0'),
            'commission_usd': Decimal('0'),
            'net_tl': Decimal('0'),
            'net_usd': Decimal('0'),
            'count': 0
        })
        
        for transaction in transactions:
            psp = transaction.psp or 'Unknown'
            category = transaction.category or 'Unknown'
            payment_method = transaction.payment_method or 'Unknown'
            
            if transaction.currency and transaction.currency.upper() == 'USD':
                psp_data[psp]['amount_usd'] += decimal_float_service.safe_decimal(transaction.amount)
                psp_data[psp]['commission_usd'] += decimal_float_service.safe_decimal(transaction.commission)
                psp_data[psp]['net_usd'] += decimal_float_service.safe_decimal(transaction.net_amount)
                category_data[category]['amount_usd'] += decimal_float_service.safe_decimal(transaction.amount)
                category_data[category]['commission_usd'] += decimal_float_service.safe_decimal(transaction.commission)
                category_data[category]['net_usd'] += decimal_float_service.safe_decimal(transaction.net_amount)
                # Payment method: Use NET amount instead of gross amount for better business analysis
                payment_method_data[payment_method]['amount_usd'] += decimal_float_service.safe_decimal(transaction.net_amount)
                payment_method_data[payment_method]['commission_usd'] += decimal_float_service.safe_decimal(transaction.commission)
                payment_method_data[payment_method]['net_usd'] += decimal_float_service.safe_decimal(transaction.net_amount)
                
                if usd_rate:
                    psp_data[psp]['amount_tl'] += decimal_float_service.safe_multiply(transaction.amount, usd_rate, 'decimal')
                    psp_data[psp]['commission_tl'] += decimal_float_service.safe_multiply(transaction.commission, usd_rate, 'decimal')
                    psp_data[psp]['net_tl'] += decimal_float_service.safe_multiply(transaction.net_amount, usd_rate, 'decimal')
                    category_data[category]['amount_tl'] += decimal_float_service.safe_multiply(transaction.amount, usd_rate, 'decimal')
                    category_data[category]['commission_tl'] += decimal_float_service.safe_multiply(transaction.commission, usd_rate, 'decimal')
                    category_data[category]['net_tl'] += decimal_float_service.safe_multiply(transaction.net_amount, usd_rate, 'decimal')
                    # Payment method: Use NET amount instead of gross amount for better business analysis
                    payment_method_data[payment_method]['amount_tl'] += decimal_float_service.safe_multiply(transaction.net_amount, usd_rate, 'decimal')
                    payment_method_data[payment_method]['commission_tl'] += decimal_float_service.safe_multiply(transaction.commission, usd_rate, 'decimal')
                    payment_method_data[payment_method]['net_tl'] += decimal_float_service.safe_multiply(transaction.net_amount, usd_rate, 'decimal')
                else:
                    psp_data[psp]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                    psp_data[psp]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                    psp_data[psp]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
                    category_data[category]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                    category_data[category]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                    category_data[category]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
                    # Payment method: Use NET amount instead of gross amount for better business analysis
                    payment_method_data[payment_method]['amount_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
                    payment_method_data[payment_method]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                    payment_method_data[payment_method]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
            else:
                psp_data[psp]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                psp_data[psp]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                psp_data[psp]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
                category_data[category]['amount_tl'] += decimal_float_service.safe_decimal(transaction.amount)
                category_data[category]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                category_data[category]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
                # Payment method: Use NET amount instead of gross amount for better business analysis
                payment_method_data[payment_method]['amount_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
                payment_method_data[payment_method]['commission_tl'] += decimal_float_service.safe_decimal(transaction.commission)
                payment_method_data[payment_method]['net_tl'] += decimal_float_service.safe_decimal(transaction.net_amount)
            
            psp_data[psp]['count'] += 1
            category_data[category]['count'] += 1
            payment_method_data[payment_method]['count'] += 1
        
        # Format data for JSON response
        summary_data = {
            'date': date,
            'date_str': date_obj.strftime('%A, %B %d, %Y'),
            'usd_rate': usd_rate,
            'total_amount_tl': float(total_amount_tl),
            'total_amount_usd': float(total_amount_usd),
            'total_commission_tl': float(total_commission_tl),
            'total_commission_usd': float(total_commission_usd),
            'total_net_tl': float(total_net_tl),
            'total_net_usd': float(total_net_usd),
            'transaction_count': len(transactions),
            'unique_clients': len(set(t.client_name for t in transactions if t.client_name)),
            'psp_summary': [
                {
                    'name': psp,
                    'amount_tl': float(data['amount_tl']),
                    'amount_usd': float(data['amount_usd']),
                    'commission_tl': float(data['commission_tl']),
                    'commission_usd': float(data['commission_usd']),
                    'net_tl': float(data['net_tl']),
                    'net_usd': float(data['net_usd']),
                    'count': data['count'],
                    # Special handling for Tether PSP - show USD as primary currency
                    'is_tether': psp.upper() == 'TETHER',
                    'primary_currency': 'USD' if psp.upper() == 'TETHER' else 'TRY'
                }
                for psp, data in psp_data.items()
            ],
            'category_summary': [
                {
                    'name': category,
                    'amount_tl': float(data['amount_tl']),
                    'amount_usd': float(data['amount_usd']),
                    'commission_tl': float(data['commission_tl']),
                    'commission_usd': float(data['commission_usd']),
                    'net_tl': float(data['net_tl']),
                    'net_usd': float(data['net_usd']),
                    'count': data['count']
                }
                for category, data in category_data.items()
            ],
            'payment_method_summary': [
                {
                    'name': payment_method,
                    'net_amount_tl': float(data['amount_tl']),  # This is now net amount, not gross
                    'net_amount_usd': float(data['amount_usd']),  # This is now net amount, not gross
                    'commission_tl': float(data['commission_tl']),
                    'commission_usd': float(data['commission_usd']),
                    'net_tl': float(data['net_tl']),
                    'net_usd': float(data['net_usd']),
                    'count': data['count']
                }
                for payment_method, data in payment_method_data.items()
            ],
            'transactions': [
                {
                    'id': t.id,
                    'client_name': t.client_name,
                    'amount': float(t.amount),
                    'commission': float(t.commission),
                    'net_amount': float(t.net_amount),
                    'currency': t.currency,
                    'psp': t.psp,
                    'category': t.category,
                    'payment_method': t.payment_method,
                    'notes': t.notes or ''
                }
                for t in transactions
            ]
        }
        
        return jsonify(summary_data)
        
    except Exception as e:
        logger.error(f"Error in API summary: {str(e)}")
        return jsonify({'error': 'Error loading summary data'}), 500