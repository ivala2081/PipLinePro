"""
Utility functions for the application
""" 